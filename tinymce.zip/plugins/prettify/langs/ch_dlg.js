tinyMCE.addI18n('ch.prettify_dlg',{
	title : '用google prettify插入代码',
	paste : '粘贴代码'
});
