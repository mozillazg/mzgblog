﻿tinyMCE.addI18n('ch.syntaxhl',{
	desc : '用Syntaxhighlighter插入代码'
});
